# DominoScorePro — Final Build Fix

This package fixes the Java/Kotlin JVM target mismatch by compiling both Java and Kotlin for JVM 17.

The GitHub Actions workflow also avoids the failing `android-actions/setup-android` action and installs Android SDK packages directly with `sdkmanager`.

## Expected output
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub
Replace the existing project/workflow files with this package, commit to `main`, then open Actions → Build Domino Score APK. The APK will be available under the workflow run's Artifacts as `DominoScore-debug`.
