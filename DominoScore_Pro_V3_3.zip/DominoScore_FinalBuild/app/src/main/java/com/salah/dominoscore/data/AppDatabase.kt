package com.salah.dominoscore.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities=[MatchEntity::class, RoundEntity::class], version=3, exportSchema=false)
abstract class AppDatabase: RoomDatabase() {
    abstract fun dao(): DominoDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        private val MIGRATION_1_2 = object : Migration(1,2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE matches ADD COLUMN fourPlayers INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN playerC TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE matches ADD COLUMN playerD TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE matches ADD COLUMN scoreC INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN scoreD INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE rounds ADD COLUMN pointsC INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE rounds ADD COLUMN pointsD INTEGER NOT NULL DEFAULT 0")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2,3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE matches ADD COLUMN gameMode TEXT NOT NULL DEFAULT 'INDIVIDUAL'")
            }
        }
        fun get(c: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "domino_pro.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { instance=it }
        }
    }
}
