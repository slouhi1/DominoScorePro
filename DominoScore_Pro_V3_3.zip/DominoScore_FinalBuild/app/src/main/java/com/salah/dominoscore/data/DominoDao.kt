package com.salah.dominoscore.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DominoDao {
    @Insert suspend fun insertMatch(match: MatchEntity): Long
    @Insert suspend fun insertRound(round: RoundEntity): Long
    @Update suspend fun updateMatch(match: MatchEntity)
    @Delete suspend fun deleteRound(round: RoundEntity)

    @Query("SELECT * FROM matches ORDER BY createdAt DESC")
    fun matches(): Flow<List<MatchEntity>>
    @Query("SELECT * FROM rounds WHERE matchId=:matchId ORDER BY createdAt ASC")
    fun rounds(matchId: Long): Flow<List<RoundEntity>>
    @Query("SELECT * FROM matches WHERE id=:id LIMIT 1")
    suspend fun match(id: Long): MatchEntity?
    @Query("SELECT * FROM matches WHERE finished = 0 ORDER BY createdAt DESC LIMIT 1")
    suspend fun activeMatch(): MatchEntity?
    @Query("SELECT * FROM rounds WHERE matchId=:id ORDER BY createdAt DESC LIMIT 1")
    suspend fun lastRound(id: Long): RoundEntity?
}
