package com.salah.dominoscore

import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.salah.dominoscore.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var dao: DominoDao
    private var current: MatchEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); dao=AppDatabase.get(this).dao(); home() }
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;setPadding(18,22,18,24);layoutDirection=ViewGroup.LAYOUT_DIRECTION_RTL}
    private fun text(s:String,size:Float)=TextView(this).apply{text=s;textSize=size;gravity=Gravity.CENTER;setPadding(8,9,8,9)}
    private fun btn(s:String,f:()->Unit)=MaterialButton(this).apply{text=s;setOnClickListener{f()}}
    private fun lp()=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)}
    private fun avatar(name:String):TextView = text(initials(name),20f).apply{setTypeface(null,Typeface.BOLD);setPadding(0,12,0,12)}
    private fun initials(name:String):String = name.trim().split(Regex("\\s+")).filter{it.isNotEmpty()}.take(2).joinToString(""){it.first().uppercase()}.ifBlank{"?"}

    private fun home(){ lifecycleScope.launch {
        val active=dao.activeMatch(); val r=root()
        r.addView(text("🁫  Domino Score Pro",30f),lp()); r.addView(text("الإصدار 3.3 — نظام فردي وفرق • بدون إعلانات",15f),lp())
        if(active!=null) r.addView(btn("▶ استئناف: ${active.teamA} × ${active.teamB}"){current=active;game()},lp())
        r.addView(btn("🎯 مباراة جديدة"){newMatch()},lp()); r.addView(btn("📋 سجل المباريات"){history()},lp()); r.addView(btn("📊 الإحصائيات"){stats()},lp()); r.addView(btn("⚙ الإعدادات"){settings()},lp()); setContentView(r)
    }}

    private fun newMatch(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val mode=Spinner(this); mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("لاعبان / فريقان","4 لاعبين — فردي","4 لاعبين — فرق 2 × 2"))
        val a=EditText(this).apply{hint="الفريق / اللاعب 1";setText("الفريق A")}; val b=EditText(this).apply{hint="الفريق / اللاعب 2";setText("الفريق B")}
        val c=EditText(this).apply{hint="اللاعب 3";setText("اللاعب C")}; val d=EditText(this).apply{hint="اللاعب 4";setText("اللاعب D")}
        val target=EditText(this).apply{hint="نقاط الفوز";setText("100");inputType=InputType.TYPE_CLASS_NUMBER}
        box.addView(text("طريقة اللعب",14f));box.addView(mode,lp());box.addView(a,lp());box.addView(b,lp());box.addView(c,lp());box.addView(d,lp());box.addView(target,lp())
        fun refresh(){val four=mode.selectedItemPosition>0;c.visibility=if(four)View.VISIBLE else View.GONE;d.visibility=if(four)View.VISIBLE else View.GONE}
        mode.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){refresh()}};refresh()
        MaterialAlertDialogBuilder(this).setTitle("إعداد المباراة").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("ابدأ"){_,_->lifecycleScope.launch{
            val pos=mode.selectedItemPosition;val four=pos>0;val gameMode=if(pos==2)"TEAMS" else "INDIVIDUAL"
            val id=dao.insertMatch(MatchEntity(teamA=a.text.toString().ifBlank{"الفريق A"},teamB=b.text.toString().ifBlank{"الفريق B"},target=target.text.toString().toIntOrNull()?.coerceAtLeast(1)?:100,fourPlayers=four,playerC=if(four)c.text.toString().ifBlank{"اللاعب C"} else "",playerD=if(four)d.text.toString().ifBlank{"اللاعب D"} else "",gameMode=gameMode))
            current=dao.match(id);game()
        }}.show()
    }

    private fun game(){
        val m=current?:return; val scroll=ScrollView(this); val r=root().apply{setPadding(10,16,10,24)};scroll.addView(r)
        val modeLabel=when{!m.fourPlayers->"فريقان";m.gameMode=="TEAMS"->"4 لاعبين • فرق 2 × 2";else->"4 لاعبين • فردي"}
        r.addView(text("🁫  مباراة الدومينو",22f),lp());r.addView(text("$modeLabel • الهدف ${m.target}",14f),lp())
        val scores=playerScores(m);val maxScore=scores.maxOfOrNull{it.second}?:0;val progress=LinearProgressIndicator(this).apply{isIndeterminate=false;max=100;progress=((maxScore.toFloat()/m.target).coerceIn(0f,1f)*100).toInt();layoutParams=LinearLayout.LayoutParams(-1,9).apply{setMargins(4,5,4,12)}};r.addView(progress)
        r.addView(text("تقدم الفوز: $maxScore / ${m.target}",12f),lp())
        r.addView(playerGrid(m),lp())
        if(m.finished){val winner=winnerName(m);val card=MaterialCardView(this).apply{radius=24f;strokeWidth=2;setPadding(12,12,12,12)};card.addView(text("🏆 الفائز\n$winner\n\n${scoreLine(m)}",21f));r.addView(card,lp())}
        else {r.addView(text("⚡ إضافة سريعة",15f).apply{setTypeface(null,Typeface.BOLD)},lp());r.addView(quickButtons(m),lp());r.addView(btn("✏️ إدخال جولة مخصصة"){round()},lp())}
        r.addView(btn("↩ التراجع عن آخر جولة"){undo()},lp());r.addView(btn("📜 سجل الجولات"){rounds()},lp());r.addView(btn("🏠 الرئيسية"){home()},lp());setContentView(scroll)
    }

    private fun playerScores(m:MatchEntity)=buildList{add(m.teamA to m.scoreA);add(m.teamB to m.scoreB);if(m.fourPlayers){add(m.playerC to m.scoreC);add(m.playerD to m.scoreD)}}
    private fun playerGrid(m:MatchEntity):LinearLayout{
        val out=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(m.gameMode=="TEAMS"&&m.fourPlayers){
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=ViewGroup.LAYOUT_DIRECTION_LTR}
            top.addView(teamCard("الفريق A",m.teamA,m.playerC,m.scoreA+m.scoreC,m.target),weightLp());top.addView(teamCard("الفريق B",m.teamB,m.playerD,m.scoreB+m.scoreD,m.target),weightLp());out.addView(top)
        } else {
            val names=playerScores(m);names.chunked(2).forEach{pair->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=ViewGroup.LAYOUT_DIRECTION_LTR};pair.forEach{p->row.addView(scoreCard(p.first,p.second,m.target),weightLp())};out.addView(row)}
        };return out
    }
    private fun weightLp()=LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,3,3,3)}
    private fun scoreCard(name:String,score:Int,target:Int)=MaterialCardView(this).apply{radius=22f;strokeWidth=2;setContentPadding(8,8,8,8);addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;addView(avatar(name));addView(text(name,15f).apply{setTypeface(null,Typeface.BOLD)});addView(text(score.toString(),40f).apply{setTypeface(null,Typeface.BOLD);setPadding(4,0,4,0)});addView(text("المتبقي ${((target-score).coerceAtLeast(0))}",11f).apply{setPadding(2,0,2,0)})})}
    private fun teamCard(team:String,p1:String,p2:String,score:Int,target:Int)=MaterialCardView(this).apply{radius=22f;strokeWidth=2;setContentPadding(8,8,8,8);addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;addView(text("$team\n$p1 + $p2",14f).apply{setTypeface(null,Typeface.BOLD)});addView(text(score.toString(),42f).apply{setTypeface(null,Typeface.BOLD)});addView(text("المتبقي ${((target-score).coerceAtLeast(0))}",11f))})}

    private fun quickButtons(m:MatchEntity):LinearLayout{
        val out=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(m.gameMode=="TEAMS"&&m.fourPlayers){listOf("الفريق A" to 0,"الفريق B" to 1).forEach{p->out.addView(quickRow(p.first){points->addPoints(points,p.second,m)},lp())}
        } else playerScores(m).forEachIndexed{i,p->out.addView(quickRow(p.first){points->addPoints(points,i,m)},lp())};return out
    }
    private fun quickRow(team:String,onAdd:(Int)->Unit)=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;layoutDirection=ViewGroup.LAYOUT_DIRECTION_LTR;addView(text(team,13f),LinearLayout.LayoutParams(0,56,1f));listOf(5,10,15,20).forEach{p->addView(btn("+$p"){onAdd(p)},LinearLayout.LayoutParams(0,56,1f).apply{setMargins(2,2,2,2)})}}

    private fun addPoints(points:Int,index:Int,m:MatchEntity){lifecycleScope.launch{
        val vals=IntArray(4)
        if(m.gameMode=="TEAMS"&&m.fourPlayers){if(index==0){vals[0]=points}else{vals[1]=points}}
        else vals[index]=points
        dao.insertRound(RoundEntity(matchId=m.id,pointsA=vals[0],pointsB=vals[1],pointsC=vals[2],pointsD=vals[3],note="إضافة سريعة"))
        val u=m.copy(scoreA=m.scoreA+vals[0],scoreB=m.scoreB+vals[1],scoreC=m.scoreC+vals[2],scoreD=m.scoreD+vals[3]);current=u.copy(finished=isFinished(u));dao.updateMatch(current!!);game();if(current!!.finished)winner(current!!)
    }}

    private fun round(){val m=current?:return;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)};val names=if(m.gameMode=="TEAMS"&&m.fourPlayers)listOf("الفريق A (${m.teamA} + ${m.playerC})","الفريق B (${m.teamB} + ${m.playerD})") else playerScores(m).map{it.first};val fields=names.map{n->EditText(this).apply{hint="نقاط $n";inputType=InputType.TYPE_CLASS_NUMBER}};fields.forEach{box.addView(it,lp())};val note=EditText(this).apply{hint="ملاحظة اختيارية"};box.addView(note,lp())
        val dialog=MaterialAlertDialogBuilder(this).setTitle("تسجيل نقاط الجولة").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",null).create();dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{val v=fields.map{it.text.toString().toIntOrNull()?:0};if(v.all{it==0}){Toast.makeText(this,"أدخل نقاطًا للجولة",Toast.LENGTH_SHORT).show();return@setOnClickListener};lifecycleScope.launch{val a=v.getOrElse(0){0};val b=v.getOrElse(1){0};val c=if(m.gameMode=="TEAMS")a else v.getOrElse(2){0};val d=if(m.gameMode=="TEAMS")b else v.getOrElse(3){0};dao.insertRound(RoundEntity(matchId=m.id,pointsA=if(m.gameMode=="TEAMS")a else v.getOrElse(0){0},pointsB=if(m.gameMode=="TEAMS")b else v.getOrElse(1){0},pointsC=if(m.gameMode=="TEAMS")0 else c,pointsD=if(m.gameMode=="TEAMS")0 else d,note=note.text.toString().trim()));val u=if(m.gameMode=="TEAMS")m.copy(scoreA=m.scoreA+a,scoreC=m.scoreC+a,scoreB=m.scoreB+b,scoreD=m.scoreD+b) else m.copy(scoreA=m.scoreA+a,scoreB=m.scoreB+b,scoreC=m.scoreC+c,scoreD=m.scoreD+d);current=u.copy(finished=isFinished(u));dao.updateMatch(current!!);dialog.dismiss();game();if(current!!.finished)winner(current!!)}}};dialog.show()}
    private fun isFinished(m:MatchEntity)=if(m.gameMode=="TEAMS"&&m.fourPlayers)(m.scoreA+m.scoreC)>=m.target||(m.scoreB+m.scoreD)>=m.target else m.scoreA>=m.target||m.scoreB>=m.target||(m.fourPlayers&&(m.scoreC>=m.target||m.scoreD>=m.target))
    private fun winnerName(m:MatchEntity):String=if(m.gameMode=="TEAMS"&&m.fourPlayers){if(m.scoreA+m.scoreC>=m.scoreB+m.scoreD)"الفريق A (${m.teamA} + ${m.playerC})" else "الفريق B (${m.teamB} + ${m.playerD})"}else playerScores(m).maxBy{it.second}.first
    private fun scoreLine(m:MatchEntity)=if(m.gameMode=="TEAMS"&&m.fourPlayers)"الفريق A: ${m.scoreA+m.scoreC}  —  ${m.scoreB+m.scoreD} :الفريق B" else if(m.fourPlayers)"${m.teamA}: ${m.scoreA}   ${m.teamB}: ${m.scoreB}\n${m.playerC}: ${m.scoreC}   ${m.playerD}: ${m.scoreD}" else "${m.scoreA}  —  ${m.scoreB}"

    private fun undo(){val m=current?:return;lifecycleScope.launch{val last=dao.lastRound(m.id)?:return@launch;dao.deleteRound(last);current=m.copy(scoreA=(m.scoreA-last.pointsA).coerceAtLeast(0),scoreB=(m.scoreB-last.pointsB).coerceAtLeast(0),scoreC=if(m.gameMode=="TEAMS") (m.scoreC-last.pointsA).coerceAtLeast(0) else (m.scoreC-last.pointsC).coerceAtLeast(0),scoreD=if(m.gameMode=="TEAMS") (m.scoreD-last.pointsB).coerceAtLeast(0) else (m.scoreD-last.pointsD).coerceAtLeast(0),finished=false);dao.updateMatch(current!!);game()}}
    private fun rounds(){val m=current?:return;lifecycleScope.launch{dao.rounds(m.id).collect{list->val r=root();r.addView(text("جولات المباراة",25f),lp());if(list.isEmpty())r.addView(text("لا توجد جولات بعد",17f),lp());list.forEachIndexed{idx,x->val s=if(m.gameMode=="TEAMS"&&m.fourPlayers)"${x.pointsA} • ${x.pointsB}" else if(m.fourPlayers)"${x.pointsA} • ${x.pointsB} • ${x.pointsC} • ${x.pointsD}" else "${x.pointsA} • ${x.pointsB}";r.addView(text("الجولة ${idx+1}: $s${if(x.note.isBlank())"" else "\n${x.note}"}",16f),lp())};r.addView(btn("رجوع"){game()},lp());setContentView(r);return@collect}}}
    private fun winner(m:MatchEntity){MaterialAlertDialogBuilder(this).setTitle("🏆 نهاية المباراة").setMessage("الفائز: ${winnerName(m)}\n${scoreLine(m)}").setPositiveButton("موافق",null).show()}

    private fun history(){lifecycleScope.launch{dao.matches().collect{list->val r=root();r.addView(text("سجل المباريات",27f),lp());if(list.isEmpty())r.addView(text("لا توجد مباريات محفوظة",17f),lp());list.forEach{m->val status=if(m.finished)"🏆 انتهت" else "🟢 مستمرة";r.addView(btn("$status\n${if(m.gameMode=="TEAMS"&&m.fourPlayers)"فرق: ${m.teamA}+${m.playerC}  ${m.scoreA+m.scoreC} — ${m.scoreB+m.scoreD}  ${m.teamB}+${m.playerD}" else if(m.fourPlayers)"${m.teamA} ${m.scoreA} • ${m.teamB} ${m.scoreB} • ${m.playerC} ${m.scoreC} • ${m.playerD} ${m.scoreD}" else "${m.teamA}  ${m.scoreA} - ${m.scoreB}  ${m.teamB}"}\nالهدف ${m.target}"){current=m;game()},lp())};r.addView(btn("رجوع"){home()},lp());setContentView(r);return@collect}}}

    private fun stats(){lifecycleScope.launch{dao.matches().collect{list->val finished=list.filter{it.finished};val r=root();r.addView(text("📊 الإحصائيات",27f),lp());r.addView(text("إجمالي المباريات: ${list.size}\nالمباريات المكتملة: ${finished.size}\nالمباريات الجارية: ${list.size-finished.size}",17f),lp());val names=linkedMapOf<String,Int>();finished.forEach{m->names[winnerName(m)]=(names[winnerName(m)]?:0)+1};r.addView(text("انتصارات اللاعبين / الفرق",18f).apply{setTypeface(null,Typeface.BOLD)},lp());if(names.isEmpty())r.addView(text("لا توجد نتائج مكتملة بعد",15f),lp()) else names.entries.sortedByDescending{it.value}.forEach{e->r.addView(text("${e.key}: ${e.value} فوز",16f),lp())};r.addView(btn("رجوع"){home()},lp());setContentView(r);return@collect}}}
    private fun settings(){val r=root();r.addView(text("الإعدادات",27f),lp());r.addView(text("الإصدار 3.3.0\n\n• 2 لاعبين / فريقين\n• 4 لاعبين فردي\n• 4 لاعبين بنظام فرق 2 × 2\n• بطاقات نتائج مع صور رمزية تلقائية\n• أزرار نقاط سريعة\n• إحصائيات الفوز\n• حفظ محلي باستخدام Room مع ترحيل تلقائي\n• بدون إعلانات أو SDK إعلاني\n• يعمل بدون إنترنت",16f),lp());r.addView(btn("رجوع"){home()},lp());setContentView(r)}
}
