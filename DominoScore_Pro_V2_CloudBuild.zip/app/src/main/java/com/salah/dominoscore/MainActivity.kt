package com.salah.dominoscore

import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.salah.dominoscore.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var dao: DominoDao
    private var current: MatchEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dao = AppDatabase.get(this).dao()
        home()
    }

    private fun root() = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER_HORIZONTAL
        setPadding(24,30,24,24)
        layoutDirection=ViewGroup.LAYOUT_DIRECTION_RTL
    }
    private fun text(s:String, size:Float)=TextView(this).apply{
        text=s; textSize=size; gravity=Gravity.CENTER; setPadding(8,12,8,12)
    }
    private fun btn(s:String, f:()->Unit)=MaterialButton(this).apply{
        text=s; setOnClickListener{f()}
    }
    private fun lp()=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)}

    private fun home(){
        val r=root()
        r.addView(text("🁫  Domino Score Pro",30f),lp())
        r.addView(text("مدير مباريات الدومينو — بدون إعلانات",15f),lp())
        r.addView(btn("🎯 مباراة جديدة"){newMatch()},lp())
        r.addView(btn("📋 سجل المباريات"){history()},lp())
        r.addView(btn("⚙ الإعدادات"){settings()},lp())
        setContentView(r)
    }

    private fun newMatch(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,4,28,0)}
        val a=EditText(this).apply{hint="الفريق الأول";setText("الفريق A")}
        val b=EditText(this).apply{hint="الفريق الثاني";setText("الفريق B")}
        val target=EditText(this).apply{hint="نقاط الفوز";setText("100");inputType=2}
        box.addView(a,lp());box.addView(b,lp());box.addView(target,lp())
        MaterialAlertDialogBuilder(this).setTitle("إعداد المباراة").setView(box)
            .setNegativeButton("إلغاء",null).setPositiveButton("ابدأ"){_,_->
                lifecycleScope.launch{
                    val id=dao.insertMatch(MatchEntity(
                        teamA=a.text.toString().ifBlank{"الفريق A"},
                        teamB=b.text.toString().ifBlank{"الفريق B"},
                        target=target.text.toString().toIntOrNull()?.coerceAtLeast(1)?:100))
                    current=dao.match(id); game()
                }
            }.show()
    }

    private fun game(){
        val m=current?:return
        val r=root()
        r.addView(text("المباراة",17f),lp())
        r.addView(text("${m.teamA}  ×  ${m.teamB}",23f),lp())
        r.addView(text("${m.scoreA}     -     ${m.scoreB}",46f).apply{
            setTypeface(null,Typeface.BOLD)
        },lp())
        r.addView(text("الهدف: ${m.target}",14f),lp())
        r.addView(btn("➕ تسجيل جولة"){round()},lp())
        r.addView(btn("↩ التراجع عن آخر جولة"){undo()},lp())
        r.addView(btn("📜 عرض الجولات"){rounds()},lp())
        r.addView(btn("🏠 الرئيسية"){home()},lp())
        setContentView(r)
    }

    private fun round(){
        val m=current?:return
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,4,28,0)}
        val a=EditText(this).apply{hint=m.teamA;inputType=2}
        val b=EditText(this).apply{hint=m.teamB;inputType=2}
        val note=EditText(this).apply{hint="ملاحظة اختيارية"}
        box.addView(a,lp());box.addView(b,lp());box.addView(note,lp())
        MaterialAlertDialogBuilder(this).setTitle("تسجيل نقاط الجولة").setView(box)
            .setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
                lifecycleScope.launch{
                    val pa=a.text.toString().toIntOrNull()?:0
                    val pb=b.text.toString().toIntOrNull()?:0
                    dao.insertRound(RoundEntity(matchId=m.id,pointsA=pa,pointsB=pb,note=note.text.toString()))
                    val u=m.copy(scoreA=m.scoreA+pa,scoreB=m.scoreB+pb)
                    val finished=u.scoreA>=u.target||u.scoreB>=u.target
                    current=u.copy(finished=finished);dao.updateMatch(current!!)
                    game()
                    if(finished) winner(u)
                }
            }.show()
    }

    private fun undo(){
        val m=current?:return
        lifecycleScope.launch{
            val last=dao.lastRound(m.id)?:return@launch
            dao.deleteRound(last)
            current=m.copy(scoreA=(m.scoreA-last.pointsA).coerceAtLeast(0),
                scoreB=(m.scoreB-last.pointsB).coerceAtLeast(0),finished=false)
            dao.updateMatch(current!!);game()
        }
    }

    private fun rounds(){
        val m=current?:return
        lifecycleScope.launch{
            dao.rounds(m.id).collect{ list->
                val r=root()
                r.addView(text("جولات المباراة",25f),lp())
                if(list.isEmpty()) r.addView(text("لا توجد جولات بعد",17f),lp())
                list.forEachIndexed{idx,x->
                    r.addView(text("الجولة ${idx+1}:  ${x.pointsA} - ${x.pointsB}${if(x.note.isBlank())"" else "\n${x.note}"}",17f),lp())
                }
                r.addView(btn("رجوع"){game()},lp());setContentView(r);return@collect
            }
        }
    }

    private fun winner(m:MatchEntity){
        val w=if(m.scoreA>=m.target)m.teamA else m.teamB
        MaterialAlertDialogBuilder(this).setTitle("🏆 نهاية المباراة")
            .setMessage("الفائز: $w\nالنتيجة: ${m.scoreA} - ${m.scoreB}")
            .setPositiveButton("موافق",null).show()
    }

    private fun history(){
        lifecycleScope.launch{
            dao.matches().collect{list->
                val r=root();r.addView(text("سجل المباريات",27f),lp())
                if(list.isEmpty()) r.addView(text("لا توجد مباريات محفوظة",17f),lp())
                list.forEach{m->
                    r.addView(text("${m.teamA}  ${m.scoreA} - ${m.scoreB}  ${m.teamB}\nالهدف ${m.target}",17f),lp())
                }
                r.addView(btn("رجوع"){home()},lp());setContentView(r);return@collect
            }
        }
    }

    private fun settings(){
        val r=root()
        r.addView(text("الإعدادات",27f),lp())
        r.addView(text("الإصدار 2.0.0\nالتطبيق يعمل محليًا ولا يحتاج إلى الإنترنت.\nلا يحتوي المشروع على أي SDK إعلاني.",17f),lp())
        r.addView(btn("رجوع"){home()},lp())
        setContentView(r)
    }
}
