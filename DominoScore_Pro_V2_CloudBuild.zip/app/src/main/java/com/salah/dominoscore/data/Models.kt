package com.salah.dominoscore.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teamA: String,
    val teamB: String,
    val target: Int = 100,
    val scoreA: Int = 0,
    val scoreB: Int = 0,
    val finished: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "rounds")
data class RoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: Long,
    val pointsA: Int,
    val pointsB: Int,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
