package com.salah.dominoscore.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities=[MatchEntity::class, RoundEntity::class], version=1, exportSchema=false)
abstract class AppDatabase: RoomDatabase() {
    abstract fun dao(): DominoDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(c: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "domino_pro.db")
                .build().also { instance=it }
        }
    }
}
