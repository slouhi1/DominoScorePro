# بناء APK من الهاتف فقط

هذا المشروع يحتوي على GitHub Actions لبناء APK على خوادم GitHub، فلا تحتاج Android Studio على هاتفك.

## الخطوات
1. أنشئ حسابًا في GitHub من الهاتف.
2. أنشئ Repository جديدًا، مثل `DominoScorePro`.
3. ارفع محتويات هذا المشروع إلى المستودع، وليس ملف ZIP نفسه.
4. افتح تبويب **Actions**.
5. اختر **Build Domino Score APK**.
6. اضغط **Run workflow**.
7. انتظر حتى تنتهي العملية بنجاح.
8. افتح نتيجة التشغيل ثم قسم **Artifacts**.
9. حمّل `DominoScore-debug`.
10. فك الضغط على الهاتف وستجد `app-debug.apk` ثم ثبته.

## ملاحظة
هذه عملية بناء Debug وليست توقيع Release للنشر على Google Play.
ولا توجد في المشروع مكتبات أو SDK إعلانية.
